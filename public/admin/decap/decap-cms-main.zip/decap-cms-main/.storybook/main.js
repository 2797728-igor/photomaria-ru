module.exports = {
  stories: [
    '../packages/decap-cms-core/src/**/*.stories.js',
    '../packages/decap-cms-ui-default/src/**/*.stories.js',
  ],
  addons: ['@storybook/addon-actions', '@storybook/addon-links'],
};
