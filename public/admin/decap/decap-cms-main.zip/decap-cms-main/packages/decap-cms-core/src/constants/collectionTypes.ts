export const FILES = 'file_based_collection';
export const FOLDER = 'folder_based_collection';
